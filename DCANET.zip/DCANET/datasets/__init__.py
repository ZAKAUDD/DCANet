from .EndoScene import EndoScene
from .kvasir_SEG import kvasir_SEG